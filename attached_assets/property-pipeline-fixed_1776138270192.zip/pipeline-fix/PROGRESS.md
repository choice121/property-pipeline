# Progress Log

  This file is the single source of truth for what has been done.
  Every AI that works on this project **must** update this file before finishing.

  ---

  ## Current Status

  **Active Stage:** Complete — All 7 stages done
  **Last Updated:** 2026-04-11
  **Last Worked On By:** Replit Agent (Stage 7)
  ---

  ### [2026-04-13] — Pipeline Bug Fix Pass (PIPE-1 through PIPE-14)

  **Completed by:** Claude (fix session)

  **What was done:**

  **PIPE-1 (Critical) — property_type mismatch fixed:**
  - Added `PROPERTY_TYPE_MAP` in `publisher_service.py` mapping HomeHarvest values (SINGLE_FAMILY, APARTMENT, TOWNHOMES, etc.) to Choice site expected values (house, apartment, townhouse, condo)
  - Applied same mapping in new `sync_fields()` function
  - Added `BACKFILL_PIPE1_property_types.sql` to fix the 58 already-live listings

  **PIPE-2 (Critical) — duplicate publish prevention fixed:**
  - Added `_check_duplicate_in_supabase()` in `publisher_service.py` — queries by address+city+state before inserting
  - Duplicates are linked to existing record rather than re-published
  - `publish()` return value now includes `was_duplicate` flag
  - Added `BACKFILL_PIPE2_remove_duplicates.sql` to clean existing duplicates

  **PIPE-3 (Critical) — source hardcoded to "realtor" fixed:**
  - Added `source` field to `ScrapeRequest` and `SearchRequest` (defaults to "realtor")
  - Added `_inject_source()` helper in `scraper_service.py`
  - Both routers (`scraper.py`, `search.py`) now call `_inject_source()` with `req.source`
  - Added Source dropdown to frontend Scraper form (Realtor.com / Zillow / Redfin)

  **PIPE-4 (Critical) — CHOICE_LANDLORD_ID warning added:**
  - `publisher_service.py` now logs a loud warning if `CHOICE_LANDLORD_ID` is not set
  - Added `BACKFILL_PIPE4_landlord_id.sql` with instructions to backfill existing records

  **PIPE-10 (Medium) — sync edited fields to live site:**
  - Added `sync_fields()` to `publisher_service.py`
  - Added `POST /publish/{id}/sync-fields` endpoint to `publisher.py`
  - Added `syncFields()` and `refreshImages()` to frontend `api/client.js`
  - `PublishButton.jsx` now shows "Sync Fields to Live Site" and "Refresh Photos" buttons for published properties

  **PIPE-11 (Medium) — removed `_clean_jwt()` JWT truncation hack:**
  - Removed the function entirely — it was truncating valid JWT signatures

  **PIPE-12 (Low) — platform boilerplate stripped from descriptions:**
  - Added `_clean_description()` with regex patterns stripping TurboTenant links, "Apply Now" calls to action, separator lines

  **PIPE-13 (Low) — application_fee explicit:**
  - `application_fee` now explicitly defaults to 0 with a comment explaining it's intentional

  **PIPE-14 (Low) — photo cap at 25:**
  - `_upload_images_to_imagekit()` now caps at 25 photos with a log warning when exceeded

  **Files changed:**
  - `backend/services/publisher_service.py` — complete rewrite with all fixes
  - `backend/services/scraper_service.py` — fixed source hardcoding, added `_inject_source()`
  - `backend/routers/publisher.py` — added `sync-fields` endpoint
  - `backend/routers/scraper.py` — added `source` field, inject call
  - `backend/routers/search.py` — added `source` field, inject call
  - `frontend/src/api/client.js` — added `syncFields`, `refreshImages`
  - `frontend/src/components/PublishButton.jsx` — added Sync Fields + Refresh Photos buttons
  - `frontend/src/pages/Scraper.jsx` — added Source dropdown (Realtor/Zillow/Redfin)

  **New files:**
  - `BACKFILL_PIPE1_property_types.sql`
  - `BACKFILL_PIPE2_remove_duplicates.sql`
  - `BACKFILL_PIPE4_landlord_id.sql`

  **Issues NOT fixed (deferred):**
  - PIPE-5: Watermark false positives — needs tuning with real data samples
  - PIPE-6: No image download progress indicator in UI
  - PIPE-7: Reorder gap handling in image_service.py
  - PIPE-8: pets_allowed null handling (Supabase schema dependent)
  - PIPE-9: available_date rarely populated by HomeHarvest — data limitation

  **Next steps:**
  1. Run the 3 backfill SQLs in Supabase SQL Editor (PIPE-1 first, then PIPE-2, then PIPE-4)
  2. Set CHOICE_LANDLORD_ID in Replit secrets
  3. Redeploy backend on Replit


  ---

  ## What Is Ready to Build

  All stages complete. The tool is fully functional end-to-end including publishing to Choice Properties.

  ---

  ## Completed Work

  ### [2026-04-11] — Bulk Publish: 50 properties live

  **Completed by:** Replit Agent

  **What was done:**
  - Discovered that HomeHarvest returns `list_price_min` / `list_price_max` for apartment complexes where `list_price` is NULL
  - Updated scraper_service.py to fall back to `list_price_min` when `list_price` is null — rent is now populated for all scraped properties
  - Scraped 200 properties each from Austin TX, Nashville TN, Denver CO, Atlanta GA, Phoenix AZ, Charlotte NC (1,000+ total)
  - Backfilled `monthly_rent` for all existing scraped properties using the same fallback logic
  - Selected 9 properties per city (6 cities = 54 candidates, capped at 50) with at least 1 downloaded image
  - Published all 50 in one automated run — 0 failures
  - Supabase now has 58 active listings across Austin, Atlanta, Phoenix, Nashville, Denver, Charlotte (plus 8 pre-existing)
  - Removed bulk_scrape_publish.py (no longer needed)

  **Issues encountered:**
  - Zillow for_rent scrapes return `list_price=NULL` for apartment complexes — solved by using `list_price_min` as fallback
  - `monthly_rent` NOT NULL constraint in Supabase required the fallback to be applied before any insert

  **Next step:**
  - Publish to production (deploy) so the admin dashboard is accessible outside Replit
  - Optionally set CHOICE_LANDLORD_ID secret if property landlord linking is needed

  ---

  ### [2026-04-11] — Stage 7: Publisher

  **Completed by:** Replit Agent

  **What was done:**
  - Implemented backend/services/publisher_service.py — ImageKit upload (v5 SDK) + Supabase insert + local DB update
  - Implemented backend/routers/publisher.py — POST /api/publish/{id} with proper 400/502/500 error handling
  - Created frontend/src/components/PublishButton.jsx — full state machine (idle → confirm → loading → success/error)
  - Updated frontend/src/pages/Editor.jsx — imports and renders PublishButton, shows published state in status field
  - All 5 credentials stored as Replit secrets (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, IMAGEKIT_PRIVATE_KEY, IMAGEKIT_PUBLIC_KEY, IMAGEKIT_URL_ENDPOINT)
  - CHOICE_LANDLORD_ID is optional — omitted from Supabase record if not set

  **Issues encountered:**
  - imagekitio v5 (5.3.0) installed instead of v3 — completely different API; fixed by using ik.files.upload() with private_key-only constructor
  - Supabase service role key returning 401 in dev shell tests — credentials are correctly stored and will be used by the running app

  **Next step:**
  - Scrape a property, mark it Ready, and test the Publish button end-to-end
  - If landlord_id is needed by the Supabase schema, add CHOICE_LANDLORD_ID secret

  ---

  ### [2026-04-10] — Stages 1–6: Full Application Build

  **Completed by:** Replit Agent

  **What was done:**

  **Stage 1 — Project Setup & Foundation:**
  - Created complete folder structure: backend/ and frontend/
  - backend/main.py — FastAPI app with CORS and health endpoint
  - backend/requirements.txt — all Python dependencies
  - backend/.env.example — template with Stage 7 vars
  - backend/database/db.py — SQLAlchemy engine, session, Base, init_db()
  - backend/database/models.py — Property model with all schema columns
  - backend/routers/health.py — GET /api/health returns {"status":"ok"}
  - backend/routers/scraper.py, properties.py, images.py, publisher.py (stub)
  - backend/services/scraper_service.py, image_service.py, publisher_service.py (empty)
  - frontend/package.json, vite.config.js (at root), tailwind.config.js, postcss.config.js
  - frontend/src/main.jsx, App.jsx, index.css
  - frontend/src/api/client.js — Axios instance + all API functions
  - SQLite DB created at backend/data/pipeline.db

  **Stage 2 — Scraping Engine:**
  - backend/services/scraper_service.py — HomeHarvest integration with field mapping and normalization
  - backend/routers/scraper.py — POST /api/scrape endpoint with upsert logic
  - backend/routers/properties.py — GET/PUT/DELETE /api/properties with search, filter, sort
  - Duplicate prevention via source_listing_id upsert

  **Stage 3 — Image Downloading & Storage:**
  - backend/services/image_service.py — download_images, delete_image, reorder_images
  - backend/routers/images.py — serve images, delete, reorder endpoints
  - Image downloads run as FastAPI BackgroundTasks after scrape

  **Stage 4 — React Frontend Foundation:**
  - frontend/src/components/Layout.jsx — nav with Library and Scrape links
  - frontend/src/pages/Library.jsx, Scraper.jsx, Editor.jsx (full implementations in stages 5+6)
  - Vite proxy /api → http://localhost:8000 configured

  **Stage 5 — Property Library UI:**
  - frontend/src/components/PropertyCard.jsx — shows photo, price, address, bed/bath/sqft, status badge
  - frontend/src/components/StatusBadge.jsx — color-coded status pills
  - frontend/src/pages/Library.jsx — property grid with search, filter by status, sort controls
  - Loading skeletons and empty state handled

  **Stage 6 — Property Editor UI:**
  - frontend/src/components/ImageGallery.jsx — horizontal scroll with delete and reorder arrows
  - frontend/src/pages/Editor.jsx — full property form, all fields, status dropdown
  - Compare with Original toggle, edited fields count display
  - Save, Mark as Ready, Delete Property actions

  **What was NOT done:**
  - Stage 7 (Publisher) — Locked, requires owner credentials (Supabase + ImageKit)

  **Issues encountered:**
  - Tailwind v4 was installed (not v3), required @tailwindcss/postcss plugin and @import "tailwindcss" CSS syntax
  - pydantic version conflict with homeharvest; resolved by allowing latest compatible versions
  - Vite config placed at workspace root to use root-level node_modules

  **Next step:**
  - Owner provides Stage 7 credentials (SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, IMAGEKIT keys, CHOICE_LANDLORD_ID)
  - Then implement publisher_service.py and publisher.py per stages/STAGE_7.md

  ---

  ## Known Issues / Blockers

  - None. All stages complete.
  - Note: CHOICE_LANDLORD_ID is not set — if the Supabase properties table requires a non-null landlord_id, add this secret and the publisher will include it automatically.

  ---

  ## How to Update This File

  When you finish any work, add an entry at the top of "Completed Work" in this format:

  ```
  ### [DATE] — Stage X: [Stage Title]
  **Completed by:** AI session
  **What was done:**
  - List every task completed
  - Be specific about files created or changed

  **What was NOT done (if anything):**
  - Any tasks left incomplete and why

  **Issues encountered:**
  - Any problems found and how they were resolved

  **Next step:**
  - Exactly what the next AI should do
  ```
